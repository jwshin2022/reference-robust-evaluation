"""Validate the archive and two saved 96-ROI certificates, without optimization."""
import hashlib
import json
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name, expected in json.loads((base / "SHA256.json").read_text()).items():
    if digest(base / name) != expected:
        raise ValueError(f"Archive hash mismatch: {name}")

sys.path.insert(0, str(base / "vendor/search/src"))
from verify_adaptive import verify

for seed in (35071, 35083):
    family = f"block_16_{seed}_6"
    fixture = base / "fixtures" / f"{family}.json"
    record = json.loads((base / "results" / f"{family}_adaptive_15.json").read_text())
    if digest(fixture) != record["input_sha256"]:
        raise ValueError(f"Fixture hash mismatch: {family}")
    report = verify(*json.loads(fixture.read_text())["models"], record["answer"])
    if not report["verified"]:
        raise ValueError(f"Unverified certificate: {family}")
    print(f"{family}: both saved endpoints verified")
