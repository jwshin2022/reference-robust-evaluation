from pathlib import Path
import fcntl,sys,os,json,subprocess,random,hashlib
P=Path(__file__).resolve().parents[1]
for f,h in json.loads((P/'configs/BLOCK_FROZEN.json').read_text())['sha'].items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h
lock=(P/'logs/confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def run(m,n,s,v,l=15):
    subprocess.run([sys.executable,'-B',str(P/'src/blocks.py'),m,*map(str,[n,s,v,l])],check=True,env=env)
for i,s in enumerate((35071,35083)):
    for n,v in [(4,4),(16,6)]:
        run('build',n,s,v)
        modes=['adaptive','scip','coupled'];random.Random(829+i+n).shuffle(modes)
        for m in modes:run(m,n,s,v)
        run('images',n,s,v)
for m in ('scip','coupled'):run(m,16,35071,6,60)
print('BLOCK_PANEL_FINISHED',flush=True)
