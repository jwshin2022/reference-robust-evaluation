from pathlib import Path
from fractions import Fraction
import os,sys,json,hashlib,fcntl,random,subprocess,shutil
P=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
assert hashlib.sha256((P/'configs/ESCALATION.md').read_bytes()).hexdigest()==read(P/'configs/ESCALATION_FROZEN.json')['sha256']
lock=(P/'logs/confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
assert 'BLOCK_PANEL_FINISHED' in (P/'logs/blocks.log').read_text()
eligible=[];cert=[]
for seed in (35071,35083):
    get=lambda m:read(P/'results'/f'block_16_{seed}_6_{m}_15.json')
    a=get('adaptive'); certified=bool(a['answer']['complete'] and a.get('check',{}).get('verified') and a['seconds']<=30 and 'max' in get('images'))
    cert.append(certified); methods=[]
    for m in ('scip','coupled'):
        rr=get(m)['answer']['sides']
        methods.append(any(x['status']=='timelimit' and (float(Fraction(x['exact']))-x['dual_bound'])*sign>1e-9 for x,sign in zip(rr,(1,-1))))
    eligible.append(certified and all(methods))
if all(eligible):print('NOT_TRIGGERED: both frozen 16-block cells met the criterion',flush=True);sys.exit(0)
if not any(cert) or shutil.disk_usage(P).free<8*2**30:print('SKIPPED: conditional extension gate',flush=True);sys.exit(0)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
for seed in (35097,35111):
    modes=['adaptive','scip','coupled'];random.Random(seed).shuffle(modes)
    for mode in ['build']+modes+['images']:
        subprocess.run([sys.executable,'-B',str(P/'src/blocks.py'),mode,'48',str(seed),'6','15'],env=env,check=True)
print('EXTENSION_FINISHED',flush=True)
