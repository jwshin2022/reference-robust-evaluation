"""Reconstruct scores using persisted local raw rows (no optimizer or image inference)."""
from pathlib import Path
from fractions import Fraction as F
import csv,math,json,hashlib
P=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text())
def raw(r,z):
    assert len(z)==len(r['domains']) and all(type(j)==int and 0<=j<n for j,n in zip(z,r['domains']))
    t=[int(r['certificate'][key]) for key in ['constant_numerator_units','constant_denominator_units']]
    for row,group in zip(r['option_tables'],r['components']):
        vs=group['variables'];assert len(vs)==1
        x=row[z[vs[0]]];t[0]+=int(x['numerator_units']);t[1]+=int(x['denominator_units'])
    return F(*t)
def writecsv(name,t):
    with (P/'results'/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(t[0]));w.writeheader();w.writerows(t)
def main():
    families=[];endpoints=[];summaries=[]
    for data in sorted((P/'fixtures').glob('*.json')):
        if data.name.startswith('.'):continue
        fx=read(data);a,b=fx['models'];ident=data.stem
        src=hashlib.sha256(data.read_bytes()).hexdigest();broad=ident.startswith('block')
        files=list((P/'results').glob(ident+'_*.json'))
        outcomes={};images={};oracle={};calls=[]
        geom='overlap' if broad else fx['kind']
        counts=[len(t) for t in a['option_tables']]
        for f in files:
            r=read(f);assert r['input_sha256']==src
            mode=r['mode'];limit=r.get('limit',60 if 'long' in mode else 15)
            if mode=='images':images=r;continue
            if mode=='exhaust':oracle=r;continue
            key=(mode.replace('_long','').replace('long','scip'),limit)
            s=r['answer'];outcomes[key]=s
            calls.append(dict(id=ident,method=key[0],seconds_per_scip_endpoint=limit,complete=s['complete'],seconds_call=r['seconds'],seconds_prepare=s.get('seconds_preparation'),seconds_build=s.get('seconds_build'),seconds_opt=s.get('seconds_solve'),seconds_check=r.get('check_seconds'),peak_process_MiB=r['peak_rss_bytes']/2**20))
            if mode=='adaptive' and s['complete']:
                assert r['check']['verified'] and int(r['check']['covered_joint_choices'])==math.prod(counts)
        target=outcomes.get(('adaptive',15));test=fx['seed']!=82119
        if not target:raise RuntimeError('Missing primary run '+ident)
        ok=target['complete']
        if ok and test:
            assert all(images.get(k)==target[k] for k in ['min','max'])
            if not broad and fx['n']==8:assert all(oracle.get(k)==target[k] for k in ['min','max']) and oracle['count']==4**8
        rc=next(x for x in calls if x['method']=='adaptive')
        time_ok=ok and rc['seconds_call']<=30
        win={k:False for k in ('scip','coupled')}
        for (m,l),s in outcomes.items():
            if m=='adaptive':continue
            for side,row in zip(('min','max'),s['sides']):
                zz=row['witness'];value=raw(a,zz)-raw(b,zz);assert str(value)==row['exact']
                bound=row['dual_bound'];pr=float(value)
                sense=1 if side=='min' else -1
                unresolved=(pr-bound)*sense
                if row['status']=='timelimit' and unresolved>1e-9 and l==15:win[m]=True
                if ok:
                    exact=F(target[side]);assert (value-exact)*sense>=0
                    # Dual bounds are numerical; allow SCIP feasibility roundoff.
                    assert (float(exact)-bound)*sense>=-2e-7,(ident,m,side)
                endpoints.append(dict(id=ident,method=m,limit_seconds=l,endpoint=side,status=row['status'],solver_seconds=row['seconds'],build_seconds=row['seconds_build'],scip_gap=row['gap'],dual_bound=bound,incumbent_exact=str(value),primal_dual_separation_pp=100*unresolved,incumbent_equals_certified=(value==F(target[side])) if ok else '',nodes=row.get('nodes','')))
            for c in calls:
                if c['method']==m and c['seconds_per_scip_endpoint']==l:
                    c['opposed_one_point_incumbent_witnesses']=F(s['min'])<F(-1,100) and F(s['max'])>F(1,100)
        rc['opposed_one_point_incumbent_witnesses']=F(target['min'])<F(-1,100) and F(target['max'])>F(1,100)
        summaries.extend(calls)
        families.append(dict(id=ident,panel='confirmation' if test else 'development',geometry=geom,rois=fx['n']*(fx.get('v',1)),blocks=fx['n'] if broad else '',raw_choices='4^'+str(fx['n']*fx.get('v',1)),retained_component_options=sum(counts),max_options=max(counts),compile_seconds=fx['seconds'],adaptive_complete=ok,adaptive_with_check_s=rc['seconds_call'],nodes=target['nodes'],adaptive_stop=target['stop_reason'],both_endpoint_masks_checked=bool(ok and test),exhaustive_assignments=oracle.get('count',0),scip_timeout=win['scip'],direct_scip_timeout=win['coupled'] if test else '',both_formulations_separated=bool(test and time_ok and all(win.values()))))
    writecsv('FAMILIES.csv',families);writecsv('ENDPOINTS.csv',endpoints);writecsv('METHOD_CALLS.csv',summaries)
    (P/'qa/SOLVER_AUDIT.json').write_text(json.dumps(dict(families=families,solver_endpoint_rows=len(endpoints),exactly_rescored_scip_witnesses=len(endpoints),clinical_reruns=0),indent=2))
if __name__=='__main__':main()
