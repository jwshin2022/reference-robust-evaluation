"""Resume from completed immutable per-call files; one fresh, single-thread worker at a time."""
from pathlib import Path
from datetime import datetime,timezone
import json,sys,subprocess,os,hashlib,random,fcntl
P=Path(__file__).resolve().parents[1]
contract=json.loads((P/'configs/CONFIRMATION.json').read_text())
for f,h in contract['hashes'].items():
    assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
lock=(P/'logs/confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def run(mode,n,seed,kind,rep):
    subprocess.run([sys.executable,'-B',str(P/'src/panel.py'),mode,str(n),str(seed),kind,str(rep)],env=env,check=True)
for idx,(kind,n,seed) in enumerate(contract['families']):
    run('build',n,seed,kind,1)
    modes=['adaptive','scip','coupled'];random.Random(2467+idx).shuffle(modes)
    for mode in modes:run(mode,n,seed,kind,1)
    if n==8:run('exhaust',n,seed,kind,1)
    run('images',n,seed,kind,1)
for mode in ['long','coupled_long']:
    run(mode,32,82131,'offset',1)
print('PANEL_FINISHED',flush=True)
