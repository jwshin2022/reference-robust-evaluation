"""Portable synthetic benchmark supplement. Run after extracting the complete ZIP."""
from pathlib import Path
import json,sys,subprocess,hashlib,shutil,tempfile
root=Path(__file__).resolve().parent
if len(sys.argv)==1 or sys.argv[1]=='verify':
    manifest=json.loads((root/'SHA256.json').read_text());bad=[]
    for f,h in manifest.items():
        if hashlib.sha256((root/f).read_bytes()).hexdigest()!=h:bad.append(f)
    if bad:raise SystemExit(str(bad))
    print('Verified archived source, input and outcome files:',len(manifest));sys.exit(0)
if sys.argv[1] not in ('check-wide','rerun-one'):raise SystemExit('Options: verify | check-wide | rerun-one')
subprocess.run([sys.executable,'-B',__file__,'verify'],check=True)
work=Path(tempfile.mkdtemp(prefix='media_solver_replay_'))
for d in ('src','sources','fixtures','results','vendor/search/sources'):(work/d).mkdir(parents=True)
shutil.copytree(root/'src',work/'src',dirs_exist_ok=True)
shutil.copytree(root/'vendor',work/'vendor',dirs_exist_ok=True)
(work/'sources/STAGE30.txt').write_text(str(work/'vendor/search'))
(work/'vendor/search/sources/PARENT.json').write_text(json.dumps({'scaling_parent':str(work/'vendor/geometry')}))
if sys.argv[1]=='rerun-one':
    for mode in ('build','adaptive','scip','coupled','exhaust','images'):
        subprocess.run([sys.executable,'-B',str(work/'src/panel.py'),mode,'8','82131','offset','1'],check=True)
else:
    sys.path.insert(0,str(work/'src'));from panel import verify
    for sd in [35071,35083]:
        ident=f'block_16_{sd}_6';fx=json.loads((root/'fixtures'/(ident+'.json')).read_text())
        proof=json.loads((root/'results'/(ident+'_adaptive_15.json')).read_text())['answer']
        assert verify(*fx['models'],proof)['verified']
    print('Independent checker verified both stored 96-ROI certificates. No search performed.')
print('Isolated path',work)
