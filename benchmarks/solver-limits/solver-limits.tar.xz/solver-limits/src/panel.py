"""Geometry-derived stress families. Each tile is separated by a background halo."""
import itertools
import json
import math
import sys
import time
import os
import hashlib
import resource
from fractions import Fraction as F
from pathlib import Path
from datetime import datetime, timezone
P = Path(__file__).resolve().parents[1]
parent = Path((P/'sources/STAGE30.txt').read_text())
sys.path.insert(0, str(parent/'src'))
from experiment import old
from adaptive_search import search
from verify_adaptive import verify
from strong_scip import solve
from independent_oracle import direct_codes, score_exact
import numpy as np
SPACING=(0.8,1.2,1.7)
TAU=1.3
old.CFG.update(spacing=SPACING,tau=TAU)
def save(path, value):
    with path.with_suffix('.part').open('x') as f:
        json.dump(value,f); f.flush();os.fsync(f.fileno())
    if path.exists():raise FileExistsError(path)
    path.with_suffix('.part').rename(path)

def geometry(i, seed, kind):
    rng=np.random.default_rng(np.random.SeedSequence([seed,i]))
    grid=np.indices((20,18,18))
    ctr=np.array([9.,8.,8.])+rng.uniform(-.45,.45,3)
    radius=np.array([2.5,2.5,2.5])+rng.uniform(-.6,.6,3)
    def ell(factor, delta):
        return sum(((grid[j]-ctr[j]-delta[j])/(radius[j]*factor))**2 for j in range(3))<=1
    a=ell(1.,(0,0,0))
    if kind=='near':
        b=a.copy() if i%8 else ell(1.15,(.7,.1,0))
    elif kind=='offset':
        b=ell(1.12,(1.4,-.6,.25))
    else:raise ValueError(kind)
    choices=[ell(f,d) for f,d in [(0.60,(-1,.1,.1)),(.90,(0,0,0)),(1.20,(.8,-.3,.2)),(1.55,(-.4,.4,.3))]]
    assert min(np.argwhere(x).min() for x in [a,b]+choices)>=2
    return a,b,choices

def marginal(tabs, maximize):
    current=F(0); op=max if maximize else min
    while True:
        z=[op(range(len(t)),key=lambda j:t[j][0]*current.denominator-current.numerator*t[j][1]) for t in tabs]
        val=F(sum(t[j][0] for t,j in zip(tabs,z)),sum(t[j][1] for t,j in zip(tabs,z)))
        if val==current:return z
        current=val

def fixture(n,seed,kind):
    groups=[[],[]];den=None
    for i in range(n):
        a,b,g=geometry(i,seed,kind)
        for compiled,rows in zip(old.compile_pair(a,b,[g],[len(g)]),groups):
            units=compiled['certificate']['area_weight_denominator']
            if den is None:den=units
            assert units==den
            rows.append([old.raw(compiled,[j]) for j in range(len(g))])
    out=[]
    for tables in groups:
        out.append({'domains':[4]*n,'components':[{'variables':[j]} for j in range(n)],
          'certificate':{'constant_numerator_units':'0','constant_denominator_units':'0','area_weight_denominator':den},
          'option_tables':[[{'numerator_units':str(x),'denominator_units':str(y)} for x,y in row] for row in tables],
          'lower_assignment':marginal(tables,False),'upper_assignment':marginal(tables,True)})
    return out

def witness_mask(n,seed,kind,z):
    tiles=[geometry(i,seed,kind) for i in range(n)]
    return tuple(np.concatenate([tile[j] if j<2 else tile[2][v] for tile,v in zip(tiles,z)],axis=0) for j in range(3))

def run(mode,n,seed,kind,rep):
    ident=f'{kind}_{n}_{seed}'; data=P/'fixtures'/(ident+'.json')
    path=data if mode=='build' else P/'results'/f'{ident}_{mode}_{rep}.json'
    if path.exists():print('retained',path.name,flush=True);return
    t=time.monotonic();r={'mode':mode,'n':n,'seed':seed,'kind':kind,'rep':rep,'start_utc':datetime.now(timezone.utc).isoformat()}
    if mode=='build':r['models']=fixture(n,seed,kind)
    else:
        a,b=json.loads(data.read_text())['models'];r['input_sha256']=hashlib.sha256(data.read_bytes()).hexdigest()
        t=time.monotonic()
        if mode=='adaptive':
            ans=search(a,b);r['search_seconds']=time.monotonic()-t
            # Independent checking has a distinct timed field.
            if ans['complete']:
                t1=time.monotonic();r['check']=verify(a,b,ans);r['check_seconds']=time.monotonic()-t1
            r['answer']=ans
        elif mode in ('scip','coupled','long','coupled_long'):
            if mode=='scip':r['answer']=solve(a,b,rep)
            else:
                from alternate import solve_form
                r['answer']=solve_form(a,b,rep,coupled=mode.startswith('coupled'),limit=60. if 'long' in mode else 15.)
        elif mode=='images':
            src=json.loads((P/'results'/f'{ident}_adaptive_{rep}.json').read_text())['answer']
            if src['complete']:
                for side in ('min','max'):
                    A,B,R=witness_mask(n,seed,kind,src['z'+side]);value=score_exact(A,R,SPACING,TAU)-score_exact(B,R,SPACING,TAU)
                    assert str(value)==src[side];r[side]=str(value)
        elif mode=='exhaust':
            vals=[old.val(a,b,z) for z in itertools.product(range(4),repeat=n)]
            r.update(min=str(min(vals)),max=str(max(vals)),count=len(vals))
        else:raise ValueError(mode)
    r.update(seconds=time.monotonic()-t,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(path,r);print(path.name,round(r['seconds'],3),r.get('answer',{}).get('complete'),[s['status'] for s in r.get('answer',{}).get('sides',[])],flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],int(sys.argv[5]))
