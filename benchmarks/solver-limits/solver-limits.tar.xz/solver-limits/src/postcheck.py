"""Exact post-hoc check of a SCIP witness on single-ROI stress fixtures.

On a Cartesian product, H(z)=sign*(q*(NA*DB-NB*DA)-p*DA*DB).
The witness value p/q is optimal if max H <= 0. A one-coordinate
replacement changes H by an affine function of all other aggregate rows.
"""
from fractions import Fraction
from itertools import product
import time,math,json,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
def state(row,z):
    return tuple(sum(t[j][h] for t,j in zip(row,z)) for h in range(4))
def h_value(row,p,q,s):
    a,d,b,e=row
    return s*(q*(a*e-b*d)-p*d*e)
def rows(f):
    aa,bb=f['models']
    assert all(int(m['certificate'][k])==0 for m in (aa,bb) for k in ['constant_numerator_units','constant_denominator_units'])
    assert all(c['variables']==[i] for m in (aa,bb) for i,c in enumerate(m['components']))
    return [[tuple(int(x[k]) for x in (u,v) for k in ('numerator_units','denominator_units')) for u,v in zip(a,b)] for a,b in zip(aa['option_tables'],bb['option_tables'])]
def bound(row,allowed,i,j,w,p,q,s):
    r=row[i][j];t=row[i][w]
    a,d,b,e=[a-b for a,b in zip(r,t)]
    c=[s*q*e,s*(-q*b-p*e),-s*q*d,s*(q*a-p*d)]
    return h_value(r,p,q,s)-h_value(t,p,q,s)+sum(max(sum(x*y for x,y in zip(c,row[k][v])) for v in avail) for k,avail in enumerate(allowed) if k!=i)
def replay_bound(row,allowed,i,j,w,p,q,s):
    # Independent finite-difference computation of the affine variation; no coefficient formula.
    base=[next(iter(x)) for x in allowed];base[i]=j
    fixed=list(state(row,base));orig=row[i][j];alt=row[i][w]
    def delta(v):
        return h_value(v,p,q,s)-h_value([x-y+z for x,y,z in zip(v,orig,alt)],p,q,s)
    d0=delta(fixed);total=d0
    for k,avail in enumerate(allowed):
        if i==k:continue
        before=row[k][base[k]]
        total+=max(delta([x-y+z for x,y,z in zip(fixed,before,row[k][vv])])-d0 for vv in avail)
    return total
def check(row,z,s,cap=65536):
    a,d,b,e=state(row,z);fraction=Fraction(a,d)-Fraction(b,e);p,q=fraction.as_integer_ratio()
    allowed=[set(range(len(r))) for r in row];removed=[]
    while True:
        count=len(removed)
        for i,avail in enumerate(allowed):
            for j in sorted(avail-{z[i]}):
                if bound(row,allowed,i,j,z[i],p,q,s)<=0:
                    avail.remove(j);removed.append((i,j))
        if count==len(removed):break
    remaining=math.prod(map(len,allowed))
    success=False
    if remaining<=cap:
        success=all(h_value(state(row,v),p,q,s)<=0 for v in product(*allowed))
    # Each eliminated state may be replaced by the witness state with nondecreasing H.
    copy=[set(range(len(r))) for r in row]
    for i,j in removed:
        assert j in copy[i] and j!=z[i] and replay_bound(row,copy,i,j,z[i],p,q,s)<=0
        copy[i].remove(j)
    assert copy==allowed
    if success:
        op=max if s==1 else min
        def ratio(v):
            a,d,b,e=state(row,v);return Fraction(a,d)-Fraction(b,e)
        assert op(ratio(v) for v in product(*copy))==fraction
    return dict(proved=success,remaining=remaining,deleted=len(removed),deletions=removed,witness=z,value=str(fraction))
def run():
    output=[]
    for seed in (82131,82147):
        for k,n in [('near',32),('offset',8),('offset',32),('offset',64)]:
            ident=f'{k}_{n}_{seed}'
            fx=json.loads((P/'fixtures'/(ident+'.json')).read_text())
            row=rows(fx);sc=json.loads((P/'results'/(ident+'_coupled_1.json')).read_text())['answer']
            pair={side:check(row,sc['z'+side],s) for side,s in [('min',-1),('max',1)]}
            if n==8:
                ex=json.loads((P/'results'/(ident+'_exhaust_1.json')).read_text())
                assert all(pair[k]['value']==ex[k] for k in ['min','max'])
            output.append(dict(id=ident,results=pair))
    p=P/'qa/SCIP_WITNESS_POSTCHECK.json'
    with p.open('x') as f:json.dump(output,f)
if __name__=='__main__':run()
