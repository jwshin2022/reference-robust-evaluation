from pathlib import Path
import sys,json,time,resource
from fractions import Fraction as F
from experiment import P,old,atomic,sha,task
from residual_search import coefficients

def solve_form(a,b,rep,coupled,limit):
    from pyscipopt import Model,quicksum
    t0=time.monotonic();base,tabs,K=old.grouped(a,b);ss=old.seeds(a,b)
    # Identical incumbent proposal rule, without residual certification/search.
    for side in ['min','max']:
        v,z=(min if side=='min'else max)((old.val(a,b,z),z)for z in ss)
        for _ in range(16):
            na,da=old.raw(a,z);nb,db=old.raw(b,z);ar,br=F(na,da),F(nb,db);zz=[0]*len(a['domains'])
            for vs,rows in tabs:
                vals=[db*c-da*d for c,d in [coefficients(r,ar,br)for _,r in rows]]
                j=(min if side=='min'else max)(range(len(vals)),key=lambda i:vals[i])
                for vi,x in zip(vs,rows[j][0]):zz[vi]=x
            vv=old.val(a,b,zz)
            if(vv<v if side=='min'else vv>v):v,z=vv,zz
            else:break
        ss.append(tuple(z))
    prep=time.monotonic()-t0;out=[]
    for side in ['min','max']:
        model=Model();model.hideOutput();model.setParam('limits/time',limit);model.setParam('limits/memory',4096);model.setParam('parallel/maxnthreads',1);model.setParam('randomization/randomseedshift',rep);model.setParam('numerics/feastol',1e-9);model.setParam('limits/gap',0.);model.setParam('limits/absgap',1e-10)
        ts=time.monotonic();xs=[]
        for i,(_,rows)in enumerate(tabs):
            xx=[model.addVar(vtype='B',name=f'x{i}_{j}')for j in range(len(rows))];xs.append(xx);model.addCons(quicksum(xx)==1)
        scale=max(base[h]+sum(max(r[h]for _,r in rows)for _,rows in tabs)for h in [1,3]);vs={}
        for h in [0,1,2]:
            lower=base[h]+sum(min(r[h]for _,r in rows)for _,rows in tabs);upper=base[h]+sum(max(r[h]for _,r in rows)for _,rows in tabs)
            v=model.addVar(lb=float(F(lower,scale)),ub=float(F(upper,scale)));model.addCons(v==float(F(base[h],scale))+quicksum(float(F(r[h],scale))*x for xx,(_,rows)in zip(xs,tabs)for x,(_,r)in zip(xx,rows)));vs[h]=v
        if coupled:
            # Model the numerator difference directly to retain cancellation in its linear bounds.
            lower=base[4]+sum(min(r[4] for _,r in rows) for _,rows in tabs)
            upper=base[4]+sum(max(r[4] for _,r in rows) for _,rows in tabs)
            diff_n=model.addVar(lb=float(F(lower,scale)),ub=float(F(upper,scale)))
            model.addCons(diff_n==float(F(base[4],scale))+quicksum(float(F(r[4],scale))*x for xx,(_,rows) in zip(xs,tabs) for x,(_,r) in zip(xx,rows)))
            bounds=[[F(*old.raw(mod,mod[key+'_assignment'])) for key in ('lower','upper')] for mod in (a,b)]
            # Round outward when passing a known exact bound to the floating solver.
            from math import nextafter,inf
            (la,ua),(lb,ub)=bounds
            yb=model.addVar(lb=nextafter(float(lb),-inf),ub=nextafter(float(ub),inf))
            diff=model.addVar(lb=nextafter(float(la-ub),-inf),ub=nextafter(float(ua-lb),inf))
            model.addCons(yb*(vs[1]+float(F(K,scale)))==vs[2])
            model.addCons(diff*vs[1]==diff_n+float(F(K,scale))*yb)
            model.setObjective(diff,'minimize' if side=='min' else 'maximize')
        else:
            ya=model.addVar(lb=0,ub=1);yb=model.addVar(lb=0,ub=1)
            model.addCons(ya*vs[1]==vs[0]);model.addCons(yb*(vs[1]+float(F(K,scale)))==vs[2])
            model.setObjective(ya-yb,'minimize' if side=='min' else 'maximize')
        for z in ss:
            sol=model.createSol();total=list(base)
            for xx,(variables,rows)in zip(xs,tabs):
                for x,(zs,row)in zip(xx,rows):
                    use=tuple(z[v]for v in variables)==tuple(zs);model.setSolVal(sol,x,int(use))
                    if use:total=[u+v for u,v in zip(total,row)]
            for h,v in vs.items():model.setSolVal(sol,v,float(F(total[h],scale)))
            ar=F(total[0],total[1]);br=F(total[2],total[3])
            if coupled:
                model.setSolVal(sol,diff_n,float(F(total[4],scale)));model.setSolVal(sol,diff,float(ar-br))
            else:model.setSolVal(sol,ya,float(ar))
            model.setSolVal(sol,yb,float(br));model.addSol(sol)
        build=time.monotonic()-ts;ts=time.monotonic();model.optimize();r={'status':str(model.getStatus()),'seconds':time.monotonic()-ts,'seconds_build':build,'gap':model.getGap(),'dual_bound':model.getDualbound(),'variables':model.getNVars(),'constraints':model.getNConss()}
        r.update(primal_bound=model.getPrimalbound(),nodes=model.getNNodes())
        if model.getNSols():
            z=[0]*len(a['domains'])
            for xx,(variables,rows)in zip(xs,tabs):
                j=max(range(len(xx)),key=lambda i:model.getVal(xx[i]));assert model.getVal(xx[j])>.999
                for vi,x in zip(variables,rows[j][0]):z[vi]=x
            r.update(witness=z,exact=str(old.val(a,b,z)))
        out.append(r)
    return {'complete':all(r['status']=='optimal'for r in out),'min':out[0].get('exact'),'max':out[1].get('exact'),'zmin':out[0].get('witness'),'zmax':out[1].get('witness'),'seconds_solve':sum(r['seconds']for r in out),'seconds_build':sum(r['seconds_build']for r in out),'seconds_preparation':prep,'sides':out,'floating_status_not_exact_certificate':True}
