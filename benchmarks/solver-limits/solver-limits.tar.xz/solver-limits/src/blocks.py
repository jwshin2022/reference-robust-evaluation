"""Finite Cartesian product of separated four-alternative, overlapping annotation blocks."""
import itertools
import json
import math
import sys
import time
import resource
from pathlib import Path
from fractions import Fraction as F
import panel
from panel import P,old,np,SPACING,TAU,score_exact,save,marginal,search,verify
from alternate import solve_form

def tile(index,seed,v):
    rng=np.random.default_rng(np.random.SeedSequence([seed,index]))
    grid=np.indices((19,19,17));A=np.zeros(grid.shape[1:],bool);B=A.copy();groups=[]
    for i in range(v):
        center=np.array([6+3*(i%3),6+3*((i//3)%2),7.])+rng.uniform(-.45,.45,3)
        rad=np.array([2.2,2.,2.4])+rng.uniform(-.35,.35,3)
        options=[]
        for delta in [(0,0,0),(1,0,0),(0,1,1),(-1,0,1)]:
            opts=sum(((grid[j]-center[j]-delta[j])/rad[j])**2 for j in range(3))<=1
            options.append(opts)
        A|=options[(index+i+1)%4];B|=options[(index+i+2)%4];groups.append(options)
    # Asymmetric, fixed, remote foreground is never covered by a reference.
    if index%3==0:A[1:3,1:3,1:3]=True
    return A,B,groups

def compile(n,seed,v):
    tables=[[],[]];unit=None
    for i in range(n):
        a,b,g=tile(i,seed,v)
        for r,rows in zip(old.compile_pair(a,b,g,[4]*v),tables):
            unit0=r['certificate']['area_weight_denominator']
            if unit is None:unit=unit0
            assert unit==unit0
            rows.append([old.raw(r,z) for z in itertools.product(range(4),repeat=v)])
    # Aggregate exactly identical metric rows as a shared lossless reduction. Keep an admissible preimage.
    index=[];retained=[[],[]]
    for aa,bb in zip(*tables):
        first={}
        for j,(ar,br) in enumerate(zip(aa,bb)):
            first.setdefault(ar+br,j)
        idx=list(first.values());index.append(idx)
        for arr,raw in zip(retained,(aa,bb)):arr.append([raw[j] for j in idx])
    out=[]
    for t in retained:
        out.append({'domains':[len(x) for x in t],'components':[{'variables':[j]} for j in range(n)],
        'certificate':{'constant_numerator_units':'0','constant_denominator_units':'0','area_weight_denominator':unit},
        'option_tables':[[{'numerator_units':str(x),'denominator_units':str(y)} for x,y in row] for row in t],
        'lower_assignment':marginal(t,False),'upper_assignment':marginal(t,True)})
    return out,index

def rescore(z,index,n,seed,v):
    pa=[];pb=[];ref=[]
    for i,j in enumerate(z):
        a,b,g=tile(i,seed,v);idx=index[i][j]
        digs=[(idx//4**k)%4 for k in reversed(range(v))]
        pa.append(a);pb.append(b);ref.append(np.logical_or.reduce([r[t] for r,t in zip(g,digs)]))
    r=np.concatenate(ref);return score_exact(np.concatenate(pa),r,SPACING,TAU)-score_exact(np.concatenate(pb),r,SPACING,TAU)

def run(mode,n,seed,v,limit=15):
    ident=f'block_{n}_{seed}_{v}';data=P/'fixtures'/(ident+'.json')
    path=data if mode=='build' else P/'results'/f'{ident}_{mode}_{limit}.json'
    if path.exists():print('retained',path.name,flush=True);return
    t=time.monotonic();r=dict(mode=mode,n=n,seed=seed,v=v,limit=limit)
    if mode=='build':r['models'],r['index']=compile(n,seed,v)
    else:
        fx=json.loads(data.read_text());a,b=fx['models'];r['input_sha256']=panel.hashlib.sha256(data.read_bytes()).hexdigest();t=time.monotonic()
        if mode=='adaptive':
            ans=search(a,b);r['search_seconds']=time.monotonic()-t
            if ans['complete']:
                t1=time.monotonic();r['check']=verify(a,b,ans);r['check_seconds']=time.monotonic()-t1
            r['answer']=ans
        if mode in ('scip','coupled'):r['answer']=solve_form(a,b,1,coupled=mode=='coupled',limit=float(limit))
        if mode=='images':
            ans=json.loads((P/'results'/f'{ident}_adaptive_15.json').read_text())['answer']
            if ans['complete']:
                for side in ('min','max'):
                    val=rescore(ans['z'+side],fx['index'],n,seed,v)
                    assert str(val)==ans[side];r[side]=str(val)
    r.update(seconds=time.monotonic()-t,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(path,r);print(path.name,round(r['seconds'],3),r.get('answer',{}).get('complete'),[s['status'] for s in r.get('answer',{}).get('sides',[])],flush=True)
if __name__=='__main__':run(sys.argv[1],*map(int,sys.argv[2:]))
